﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Data.SqlClient;
using System.Data;

namespace SisACZ
{
    class Usuario
    {
        public int ID { get; set; }
        public string Nome { get; set; }
        public string Login { get; set; }
        public string Senha { get; set; }
        public string Celular { get; set; }
        public DateTime Data_Nascimento { get; set; }
        public string CEP { get; set; }
        public string Endereço { get; set; }
        public string Número { get; set; }
        public string Cidade { get; set; }
        public string Bairro { get; set; }

        public List<Usuario> listausuario()
        {
            List<Usuario> li = new List<Usuario>();
            SqlConnection con = ClassConecta.ObterConexao();
            SqlCommand cmd = con.CreateCommand();
            cmd.CommandText = "SELECT * FROM Usuario";
            cmd.CommandType = CommandType.Text;
            SqlDataReader dr = cmd.ExecuteReader();
            while (dr.Read())
            {
                Usuario u = new Usuario();
                u.ID = (int)dr["Id"];
                u.Nome = dr["nome"].ToString();
                u.Login = dr["login"].ToString();
                u.Senha = "******";
                u.Celular = dr["celular"].ToString();
                u.Data_Nascimento = Convert.ToDateTime(dr["dt_nascimento"]);
                u.CEP = dr["cep"].ToString();
                u.Endereço = dr["endereco"].ToString();
                u.Número = dr["numero"].ToString();
                u.Cidade = dr["cidade"].ToString();
                u.Bairro = dr["bairro"].ToString();
                li.Add(u);
            }
            return li;
        }
        public void Inserir(string nome, string login, string senha, string celular, DateTime dt_nascimento, string cep, string endereco, string numero, string cidade, string bairro)
        {
            SqlConnection con = ClassConecta.ObterConexao();
            SqlCommand cmd = con.CreateCommand();
            cmd.CommandText = "INSERT INTO Usuario(nome,login,senha,celular,dt_nascimento,cep,endereco,numero,cidade,bairro) VALUES ('" + nome + "','" + login + "','" + senha + "','" + celular + "',Convert(DateTime,'" + dt_nascimento + "',103),'" + cep + "','" + endereco + "','" + numero + "','" + cidade + "','" + bairro + "')";
            cmd.CommandType = CommandType.Text;
            cmd.ExecuteNonQuery();
            ClassConecta.FecharConexao();
        }

        public void Localiza(int id)
        {
            SqlConnection con = ClassConecta.ObterConexao();
            SqlCommand cmd = con.CreateCommand();
            cmd.CommandText = "SELECT * FROM Usuario WHERE Id='" + id + "'";
            cmd.CommandType = CommandType.Text;
            SqlDataReader dr = cmd.ExecuteReader();
            while (dr.Read())
            {
                Nome = dr["nome"].ToString();
                Login = dr["login"].ToString();
                Senha = dr["senha"].ToString();
                Celular = dr["celular"].ToString();
                Data_Nascimento = Convert.ToDateTime(dr["dt_nascimento"]);
                CEP = dr["cep"].ToString();
                Endereço = dr["endereco"].ToString();
                Número = dr["numero"].ToString();
                Cidade = dr["bairro"].ToString();
                Bairro = dr["bairro"].ToString();
            }
        }

        public void Atualizar(int id, string nome, string login, string senha, string celular, DateTime dt_nascimento, string cep, string endereco, string numero, string cidade, string bairro)
        {
            SqlConnection con = ClassConecta.ObterConexao();
            SqlCommand cmd = con.CreateCommand();
            cmd.CommandText = "UPDATE Usuario SET nome='" + nome + "',login='" + login + "',senha='" + senha + "',celular='" + celular + "',dt_nascimento=Convert(DateTime,'" + dt_nascimento + "',103),cep='" + cep + "',endereco='" + endereco + "',numero='" + numero + "',cidade='" + cidade + "',bairro='" + bairro + "' WHERE Id = '" + id + "'";
            cmd.CommandType = CommandType.Text;
            cmd.ExecuteNonQuery();
            ClassConecta.FecharConexao();
        }

        public void Exclui(int id)
        {
            SqlConnection con = ClassConecta.ObterConexao();
            SqlCommand cmd = con.CreateCommand();
            cmd.CommandText = "DELETE FROM Usuario WHERE Id='" + id + "'";
            cmd.CommandType = CommandType.Text;
            cmd.ExecuteNonQuery();
            ClassConecta.FecharConexao();
        }
    }
}